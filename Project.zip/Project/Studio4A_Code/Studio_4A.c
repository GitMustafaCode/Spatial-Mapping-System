// 2DX4_Knowledge_Thread_3_Session 0
// This program illustrates the use of SysTick in the C language.
// Note the library headers asscoaited are PLL.h and SysTick.h,
// which define functions and variables used in PLL.c and SysTick.c.
//

//
//  Written by Ama Simons
//  January 18, 2020
//  Last Update: January 18, 2020


#include <stdint.h>
#include "tm4c1294ncpdt.h"
#include "PLL.h"
#include "SysTick.h" 


void PortN_Init(void){
	//Use PortN onboard Pin	
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R12;				// activate clock for Port N
	while((SYSCTL_PRGPIO_R&SYSCTL_PRGPIO_R12) == 0){};	// allow time for clock to stabilize
	GPIO_PORTN_DIR_R |= 0x1D;        								// make PN0 as output (LED1)
  GPIO_PORTN_AFSEL_R &= ~0x1D;     								// disable alt funct on PN0
  GPIO_PORTN_DEN_R |= 0x1C;        								// enable digital I/O on PN0
																									
  GPIO_PORTN_AMSEL_R &= ~0x1D;     								// disable analog functionality on PN0		
	
	GPIO_PORTN_DATA_R ^= 0b00000001; 								
	SysTick_Wait10ms(10);														
	GPIO_PORTN_DATA_R ^= 0b00000001;	
	return;
}

void RedDutyCycle_Percent(uint8_t duty){
		float percent;	
		percent = ((float)duty*1000)/(255);
		int percent_int;
		percent_int = (int)percent;
		GPIO_PORTN_DATA_R ^= 0b00000100;
		SysTick_Wait10us((percent_int)/10);  
		GPIO_PORTN_DATA_R ^= 0b00000100;
		SysTick_Wait10us((1000-percent_int)/10);
}

void GreenDutyCycle_Percent(uint8_t duty){
		float percent;	
		percent = ((float)duty*1000)/(255);
		int percent_int;
		percent_int = (int)percent;
		GPIO_PORTN_DATA_R ^= 0b00001000;
		SysTick_Wait10us((percent_int)/10);  
		GPIO_PORTN_DATA_R ^= 0b00001000;
		SysTick_Wait10us((1000-percent_int)/10);
}

void BlueDutyCycle_Percent(uint8_t duty){
		float percent;	
		percent = ((float)duty*1000)/(255);
		int percent_int;
		percent_int = (int)percent;
		GPIO_PORTN_DATA_R ^= 0b00010000;
		SysTick_Wait10us((percent_int)/10);  
		GPIO_PORTN_DATA_R ^= 0b00010000;
		SysTick_Wait10us((1000-percent_int)/10);
}

void RGBDutyCycle_Percent(uint8_t RedDuty, uint8_t GreenDuty, uint8_t BlueDuty){
		
	  GPIO_PORTN_DATA_R ^= 0b00011100;
	  for(int i = 0; i < 255; i++){
			
			if(i == RedDuty)
			{
				GPIO_PORTN_DATA_R ^= 0b00000100;
			}
			
			if(i == GreenDuty)
			{
				GPIO_PORTN_DATA_R ^= 0b00001000;
			}
			
			if(i == BlueDuty)
			{
				GPIO_PORTN_DATA_R ^= 0b00010000;
			}
		  
		
			
			SysTick_Wait10us(1000);
			
		}
		
	
		
}
/*
void IntensitySteps(){
	uint8_t duty = 0;	
	while(duty < 255){
		
		for(int i = 0; i < 10; i++){
			DutyCycle_Percent(duty);
			
		}
		duty += 25;
  }
	
	while(duty > 0){
		
		for(int i = 0; i < 10; i++){
			DutyCycle_Percent(duty);
			
		}
		duty -= 25;
  }
	
}
*/

void IntensitySteps(){
	
	int i,j;
	
	for(i=1;i<=10;i++)
	{
		for(j=0;j<10;j++)
		{
			RedDutyCycle_Percent(25*i);
		}
	}
	for(i=10;i>=1;i--)
	{
		for(j=0;j<10;j++)
		{
			RedDutyCycle_Percent(25*i);
		}
	}
}

int main(void){
	
	PLL_Init();																			// Default Set System Clock to 120MHz
	SysTick_Init();																	// Initialize SysTick configuration
	PortN_Init();																		// Initialize Port N 
	
	uint8_t RedDuty = 128;		
	uint8_t GreenDuty = 128;	
	uint8_t BlueDuty = 0;		// 128 / 255 = 50 percent duty cycle
									
	
	while(1){
		RGBDutyCycle_Percent(RedDuty, GreenDuty, BlueDuty);
	}
	
}





