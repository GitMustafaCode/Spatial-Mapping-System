// clang-format off
#include <stdint.h>
#include "tm4c1294ncpdt.h"
#include "PLL.h"
#include "SysTick.h"
// clang-format on

void PortH_Init(void)
{
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R7; // Activate the clock for Port H
    while ((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R7) == 0)
    {
    }; // Allow time for clock to stabilize

    GPIO_PORTH_DIR_R = 0b00001111; // Enable PH0, PH1, PH2, and PH3 as outputs.
    GPIO_PORTH_DEN_R = 0b00001111; // Enable PH0, PH1, PH2 and PH3 as digital pins.
    return;
}

/*
void PortL_Init(void)
{
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R10; // Activate the clock for Port L
    while ((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R10) == 0)
    {
    }; // Allow time for clock to stabilize

    GPIO_PORTL_DIR_R = 0b00000011; // Enable PL0, PL1, PL2, and PL3 as outputs.
    GPIO_PORTL_DEN_R = 0b00000011; // Enable PL0, PL1, PL2 and PL3 as digital pins.
    return;
}
*/

void PortM_Init(void)
{
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R11; // Activate the clock for Port M
    while ((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R11) == 0)
    {
    }; // Allow time for clock to stabilize

    GPIO_PORTM_DIR_R = 0b00000000; // Enable PM0 and PM1 as inputs
    GPIO_PORTM_DEN_R = 0b00000001; // Enable PM0, PM1, PM2, and PM3 as digital pins
    return;
}

void PortN_Init(void)
{
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R12; // Activate the clock for Port N
    while ((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R12) == 0)
    {
    }; // Allow time for clock to stabilize

    GPIO_PORTN_DIR_R = 0b00000011; // Enable PN0 as output
    GPIO_PORTN_DEN_R = 0b00000011; // Enable PN0 as a digital pin
    return;
}

 //256 steps for 45 deg

int steps = 0;
void LEDON()
{
		//uint32_t delay = 1;
    if (GPIO_PORTM_DATA_R == 0x01)
    {
        GPIO_PORTN_DATA_R ^= 0x02;
			  

        while (GPIO_PORTM_DATA_R == 0x01)
        {
        }
    }
		
}



void button0()
{
	uint32_t delay = 1;
	
	if((GPIO_PORTN_DATA_R == 0x02) && (steps<2048))
	{
		GPIO_PORTH_DATA_R = 0b00000011;
		SysTick_Wait10ms(delay);										// What if we want to reduce the delay between steps to be less than 10 ms?
		GPIO_PORTH_DATA_R = 0b00000110;
		SysTick_Wait10ms(delay);
		GPIO_PORTH_DATA_R = 0b00001100;
		SysTick_Wait10ms(delay);
		GPIO_PORTH_DATA_R = 0b00001001;
		SysTick_Wait10ms(delay);
		
		steps += 4;	
			
		if((steps!=0)&&(steps%256 == 0))
		{
			GPIO_PORTN_DATA_R ^= 0x01;
			SysTick_Wait10ms(5);
			GPIO_PORTN_DATA_R ^= 0x01;
		}
	}		//increment steps
	
	else
	{
		GPIO_PORTN_DATA_R = 0x00;
		steps = 0;
		
	}
	
		
}
	
	
	
	


int main(void) 
{
	
	PLL_Init();
	SysTick_Init();

	//PortL_Init();
	PortM_Init();
	PortH_Init();
	PortN_Init();
	
	GPIO_PORTN_DATA_R = 0x00;
	
	while (1)
	{ // Keep checking if a button is pressed

			LEDON();
			button0();
	}
	return 0;
}